WebCache does not keep track of nor store your data. 
