WebCache
========

This is a chrome browser extension that allows the user to view a cached version of the current webpage

Install this extension here: https://chrome.google.com/webstore/detail/webcache/cmmlgikpahieigpcclckfmhnchdlfnjd

Images by Jason Rainbows

v2.0.1
